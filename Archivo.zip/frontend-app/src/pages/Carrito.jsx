
export default function Product(){

    return(
        <div>Hola</div>
    )
}